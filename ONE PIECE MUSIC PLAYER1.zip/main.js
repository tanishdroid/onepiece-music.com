function enter() {
  document.getElementById("loaded").style = "display: none;"
  var obj = document.getElementById("a"); obj.play();
}
